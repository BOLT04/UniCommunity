package pt.isel.unicommunityprototype.kotlinx

import androidx.appcompat.app.AppCompatActivity
import pt.isel.unicommunityprototype.UniCommunityApplication

fun AppCompatActivity.getUniApplication() = this.application as UniCommunityApplication