package pt.isel.unicommunityprototype.repository.data_access

import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import pt.isel.unicommunityprototype.UniCommunityApplication

class FirestoreIntermediator(private val app: UniCommunityApplication) {
    val TAG = "FirestoreIntermediator"

    val db = FirebaseFirestore.getInstance()
    private val boardsCol = db.collection("boards")

    //codigo de escrever um documento na col (create announcement numa determinada board)
    fun createAnnouncement(boardId: Int, title: String, content: String) {
        // Create a new announcement
        val announcement = HashMap<String, Any>()
        announcement["title"] = title
        announcement["content"] = content
        announcement["created"] = FieldValue.serverTimestamp()//TODO: is this how we get the date of the server?

        // Add a new document(announcement) on the specified board
        boardsCol
            .document(boardId.toString())
            .collection("announcements")
            .add(announcement)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "Announcement created with success with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error adding announcement document", e)
            }
    }
    //codigo de subcrever listener numa certa col (estar a ouvir por notificaçoes de uma determinada board)
}