package pt.isel.unicommunityprototype.common

const val USER_PANEL_VIEW_MODEL_KEY = "User Panel view model key"

//INTENTS
const val PRIVATE_PROFILE = "PrivateProfile"

const val TEAM_NOTIFICATION_CHANNEL_ID: String = "TeamNotificationChannelId"
const val DB_UPDATE_JOB_ID : String = "DB_UPDATE_JOB_ID"
const val NOTIFICATION_ID = 100012