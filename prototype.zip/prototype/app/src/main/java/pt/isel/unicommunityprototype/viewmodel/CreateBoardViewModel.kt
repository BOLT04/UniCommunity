package isel.pt.yama.viewmodel

import android.arch.lifecycle.ViewModel

/*
class CreateBoardViewModel(private val repo : Repository) : ViewModel() {


}
*/
